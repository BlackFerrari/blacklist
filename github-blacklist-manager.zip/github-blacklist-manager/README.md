# GitHub Blacklist IP Manager

A GitHub Pages frontend backed by a Cloudflare Worker. Contributors use a shared portal password; they do not need GitHub accounts. The Worker stores the GitHub token as a secret and updates `blacklist.txt` via the GitHub Contents API.

## Architecture

- **GitHub Pages** hosts `index.html`.
- **Public GitHub repository** stores `blacklist.txt`; its Raw URL returns plain text.
- **Cloudflare Worker** authenticates portal requests, validates IPs, and commits changes using a narrowly scoped GitHub token.
- Portal sessions are signed and expire after two hours. The token is held in browser memory only and is cleared on sign-out/reload.

## 1. Create the GitHub repository

1. Create a **public** repository, e.g. `blacklist-manager`.
2. Upload `index.html`, `blacklist.txt`, `README.md`, `worker.js`, `wrangler.toml`, and `.github/workflows/validate-blacklist.yml`.
3. In **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
4. The page URL will look like `https://YOUR-USERNAME.github.io/blacklist-manager/`.
5. The raw list URL will be `https://raw.githubusercontent.com/YOUR-USERNAME/blacklist-manager/main/blacklist.txt`.

## 2. Create a fine-grained GitHub token (backend only)

1. GitHub **Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token**.
2. Choose the correct resource owner and **Only select repositories**, selecting this repository.
3. Grant **Repository permissions → Contents: Read and write** only. No other permissions are required for this flow.
4. Generate and copy the token. **Never** paste it into `index.html`, a public file, the README, browser storage, or a screenshot.

The repository must be public if anonymous consumers need to read the GitHub Raw URL. The management token can still be restricted to the one repository.

## 3. Deploy the Cloudflare Worker

1. Create/sign in to Cloudflare at https://dash.cloudflare.com/ and open **Workers & Pages**.
2. Create a Worker (e.g. `blacklist-manager-api`) and replace its starter code with `worker.js` from this repository. Deploy it.
3. In Worker **Settings → Variables and Secrets**, configure:

| Name | Type | Value |
|---|---|---|
| `GITHUB_TOKEN` | Secret | Fine-grained token from step 2 |
| `PORTAL_PASSWORD` | Secret | Strong, unique shared password (20+ characters recommended) |
| `SESSION_SECRET` | Secret | Random secret at least 32 characters long |
| `GITHUB_OWNER` | Variable | GitHub username or organization |
| `GITHUB_REPO` | Variable | `blacklist-manager` |
| `GITHUB_BRANCH` | Variable | `main` |
| `FILE_PATH` | Variable | `blacklist.txt` |
| `ALLOWED_ORIGIN` | Variable | Exact Pages origin, e.g. `https://YOUR-USERNAME.github.io` (no trailing slash or path) |

4. Save and redeploy if prompted. Test `https://YOUR-WORKER.workers.dev/health`; it should return `{"ok":true}`.
5. Add Cloudflare rate limiting to `POST /api/login` if available on your plan. Do not expose the Worker to unrestricted password guessing.

Generate a strong random secret with a trusted password manager or your operating system's cryptographic random generator. Avoid weak or reused secrets.

## 4. Configure the portal

Open `index.html` and replace the two constants near the bottom:

```js
const API_BASE = "https://YOUR-WORKER-NAME.YOUR-SUBDOMAIN.workers.dev";
const RAW_URL = "https://raw.githubusercontent.com/YOUR-GITHUB-USERNAME/YOUR-PUBLIC-REPO/main/blacklist.txt";
```

Use your real Worker URL and GitHub repository path. Do not put the token or portal password in this file. Commit and push the changes; wait for GitHub Pages to publish.

## 5. Test the full flow

1. Open the GitHub Pages URL and sign in using `PORTAL_PASSWORD`.
2. Add, edit, search, and delete test IPs.
3. Confirm each successful change creates a commit in GitHub and updates `blacklist.txt`.
4. Retrieve the public raw body:

```bash
curl https://raw.githubusercontent.com/YOUR-USERNAME/blacklist-manager/main/blacklist.txt
```

The response body contains one IP per line (and the initial comment line until you remove it). GitHub's CDN may briefly serve a cached copy after a commit.

## Security and limits

- **The list is public.** Anyone can read/copy it; never put confidential data in it.
- This starter uses a **shared password**, so contributors are not individually identified and access cannot be revoked per person. Rotate the password when needed. For individual accounts, replace this with an identity provider and per-user authorization.
- Configure login rate limiting. This starter does not claim to implement durable per-IP rate limiting itself.
- HTTPS only. Keep the GitHub token in Cloudflare encrypted secrets and scope it to this one repository with Contents read/write only.
- CORS is a browser protection, not a replacement for authentication. The API also verifies a signed, expiring session token.
- Server-side IPv4/IPv6 validation and duplicate checks are applied. The GitHub file SHA is used to detect concurrent updates; if the file is being edited simultaneously, refresh and retry if prompted.
- The raw URL may take a short time to reflect commits due to CDN caching.
- Review current GitHub and Cloudflare plan terms, quotas, and account requirements before production use.
